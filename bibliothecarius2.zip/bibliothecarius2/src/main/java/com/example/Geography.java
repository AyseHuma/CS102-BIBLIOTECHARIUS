package com.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;

public class Geography extends Category {
    String countryCode; 

    // Public for access in FlagYesNo
    public static final Map<String, String> countryCodeMap = Map.ofEntries(
        Map.entry("Albania", "al"),
        Map.entry("Burkina Faso", "bf"),
        Map.entry("Bolivia", "bo"),
        Map.entry("Christmas Island", "cx"),
        Map.entry("Guadeloupe", "gp"),
        Map.entry("Guyana", "gy"),
        Map.entry("Kyrgyzstan", "kg"),
        Map.entry("Saint Kitts and Nevis", "kn"),
        Map.entry("Latvia", "lv"),
        Map.entry("Montserrat", "ms"),
        Map.entry("Nauru", "nr"),
        Map.entry("Palestine", "ps"),
        Map.entry("Qatar", "qa"),
        Map.entry("Serbia", "rs"),
        Map.entry("Seychelles", "sc"),
        Map.entry("South Sudan", "ss"),
        Map.entry("Swaziland", "sz"),
        Map.entry("French Southern Territories", "tf"),
        Map.entry("Holy See", "va"),
        Map.entry("Ghana", "gh"),
        Map.entry("Gibraltar", "gi"),
        Map.entry("Greenland", "gl"),
        Map.entry("Gambia", "gm"),
        Map.entry("Guinea", "gn"),
        Map.entry("Equatorial Guinea", "gq"),
        Map.entry("Greece", "gr"),
        Map.entry("South Georgia and the South Sandwich Islands", "gs"),
        Map.entry("Guatemala", "gt"),
        Map.entry("Guam", "gu"),
        Map.entry("Guinea-Bissau", "gw"),
        Map.entry("Hong Kong", "hk"),
        Map.entry("Heard Island and McDonald Islands", "hm"),
        Map.entry("Honduras", "hn"),
        Map.entry("Croatia", "hr"),
        Map.entry("Haiti", "ht"),
        Map.entry("Hungary", "hu"),
        Map.entry("Indonesia", "id"),
        Map.entry("Ireland", "ie"),
        Map.entry("Israel", "il"),
        Map.entry("Isle of Man", "im"),
        Map.entry("India", "in"),
        Map.entry("British Indian Ocean Territory", "io"),
        Map.entry("Iraq", "iq"),
        Map.entry("Iran", "ir"),
        Map.entry("Iceland", "is"),
        Map.entry("Italy", "it"),
        Map.entry("Jersey", "je"),
        Map.entry("Jamaica", "jm"),
        Map.entry("Jordan", "jo"),
        Map.entry("Japan", "jp"),
        Map.entry("Kenya", "ke"),
        Map.entry("Cambodia", "kh"),
        Map.entry("Kiribati", "ki"),
        Map.entry("Comoros", "km"),
        Map.entry("North Korea", "kp"),
        Map.entry("South Korea", "kr"),
        Map.entry("Kuwait", "kw"),
        Map.entry("Cayman Islands", "ky"),
        Map.entry("Kazakhstan", "kz"),
        Map.entry("Laos", "la"),
        Map.entry("Lebanon", "lb"),
        Map.entry("Saint Lucia", "lc"),
        Map.entry("Liechtenstein", "li"),
        Map.entry("Sri Lanka", "lk"),
        Map.entry("Liberia", "lr"),
        Map.entry("Lesotho", "ls"),
        Map.entry("Lithuania", "lt"),
        Map.entry("Luxembourg", "lu"),
        Map.entry("Libya", "ly"),
        Map.entry("Morocco", "ma"),
        Map.entry("Monaco", "mc"),
        Map.entry("Moldova", "md"),
        Map.entry("Montenegro", "me"),
        Map.entry("Saint Martin", "mf"),
        Map.entry("Madagascar", "mg"),
        Map.entry("Marshall Islands", "mh"),
        Map.entry("North Macedonia", "mk"),
        Map.entry("Mali", "ml"),
        Map.entry("Myanmar", "mm"),
        Map.entry("Mongolia", "mn"),
        Map.entry("Macau", "mo"),
        Map.entry("Northern Mariana Islands", "mp"),
        Map.entry("Martinique", "mq"),
        Map.entry("Mauritania", "mr"),
        Map.entry("Malta", "mt"),
        Map.entry("Mauritius", "mu"),
        Map.entry("Maldives", "mv"),
        Map.entry("Malawi", "mw"),
        Map.entry("Mexico", "mx"),
        Map.entry("Malaysia", "my"),
        Map.entry("Mozambique", "mz"),
        Map.entry("Namibia", "na"),
        Map.entry("New Caledonia", "nc"),
        Map.entry("Niger", "ne"),
        Map.entry("Norfolk Island", "nf"),
        Map.entry("Nigeria", "ng"),
        Map.entry("Nicaragua", "ni"),
        Map.entry("Netherlands", "nl"),
        Map.entry("Norway", "no"),
        Map.entry("Nepal", "np"),
        Map.entry("Niue", "nu"),
        Map.entry("New Zealand", "nz"),
        Map.entry("Oman", "om"),
        Map.entry("Panama", "pa"),
        Map.entry("Peru", "pe"),
        Map.entry("French Polynesia", "pf"),
        Map.entry("Papua New Guinea", "pg"),
        Map.entry("Philippines", "ph"),
        Map.entry("Pakistan", "pk"),
        Map.entry("Poland", "pl"),
        Map.entry("Saint Pierre and Miquelon", "pm"),
        Map.entry("Pitcairn Islands", "pn"),
        Map.entry("Puerto Rico", "pr"),
        Map.entry("Portugal", "pt"),
        Map.entry("Palau", "pw"),
        Map.entry("Paraguay", "py"),
        Map.entry("Reunion", "re"),
        Map.entry("Romania", "ro"),
        Map.entry("Russia", "ru"),
        Map.entry("Rwanda", "rw"),
        Map.entry("Saudi Arabia", "sa"),
        Map.entry("Solomon Islands", "sb"),
        Map.entry("Sudan", "sd"),
        Map.entry("Sweden", "se"),
        Map.entry("Singapore", "sg"),
        Map.entry("Saint Helena, Ascension and Tristan da Cunha", "sh"),
        Map.entry("Slovenia", "si"),
        Map.entry("Svalbard and Jan Mayen", "sj"),
        Map.entry("Slovakia", "sk"),
        Map.entry("Sierra Leone", "sl"),
        Map.entry("San Marino", "sm"),
        Map.entry("Senegal", "sn"),
        Map.entry("Somalia", "so"),
        Map.entry("Suriname", "sr"),
        Map.entry("São Tomé and Príncipe", "st"),
        Map.entry("El Salvador", "sv"),
        Map.entry("Sint Maarten", "sx"),
        Map.entry("Syria", "sy"),
        Map.entry("Turks and Caicos Islands", "tc"),
        Map.entry("Chad", "td"),
        Map.entry("Togo", "tg"),
        Map.entry("Thailand", "th"),
        Map.entry("Tajikistan", "tj"),
        Map.entry("Tokelau", "tk"),
        Map.entry("Timor-Leste", "tl"),
        Map.entry("Turkmenistan", "tm"),
        Map.entry("Tunisia", "tn"),
        Map.entry("Tonga", "to"),
        Map.entry("Turkey", "tr"),
        Map.entry("Trinidad and Tobago", "tt"),
        Map.entry("Tuvalu", "tv"),
        Map.entry("Taiwan", "tw"),
        Map.entry("Tanzania", "tz"),
        Map.entry("Ukraine", "ua"),
        Map.entry("Uganda", "ug"),
        Map.entry("United States", "us"),
        Map.entry("Uruguay", "uy"),
        Map.entry("Uzbekistan", "uz"),
        Map.entry("Saint Vincent and the Grenadines", "vc"),
        Map.entry("Venezuela", "ve"),
        Map.entry("British Virgin Islands", "vg"),
        Map.entry("U.S. Virgin Islands", "vi"),
        Map.entry("Vietnam", "vn"),
        Map.entry("Vanuatu", "vu"),
        Map.entry("Wallis and Futuna", "wf"),
        Map.entry("Samoa", "ws"),
        Map.entry("Kosovo", "xk"),
        Map.entry("Yemen", "ye"),
        Map.entry("Mayotte", "yt"),
        Map.entry("South Africa", "za"),
        Map.entry("Zambia", "zm"),
        Map.entry("Zimbabwe", "zw"),
        Map.entry("Andorra", "ad"),
        Map.entry("United Arab Emirates", "ae"),
        Map.entry("Antigua and Barbuda", "ag"),
        Map.entry("Anguilla", "ai"),
        Map.entry("Armenia", "am"),
        Map.entry("Angola", "ao"),
        Map.entry("Antarctica", "aq"),
        Map.entry("Argentina", "ar"),
        Map.entry("American Samoa", "as"),
        Map.entry("Austria", "at"),
        Map.entry("Australia", "au"),
        Map.entry("Aruba", "aw"),
        Map.entry("Åland Islands", "ax"),
        Map.entry("Azerbaijan", "az"),
        Map.entry("Bosnia and Herzegovina", "ba"),
        Map.entry("Barbados", "bb"),
        Map.entry("Bangladesh", "bd"),
        Map.entry("Belgium", "be"),
        Map.entry("Bulgaria", "bg"),
        Map.entry("Bahrain", "bh"),
        Map.entry("Burundi", "bi"),
        Map.entry("Benin", "bj"),
        Map.entry("Saint Barthélemy", "bl"),
        Map.entry("Bermuda", "bm"),
        Map.entry("Brunei", "bn"),
        Map.entry("Caribbean Netherlands", "bq"),
        Map.entry("Brazil", "br"),
        Map.entry("Bahamas", "bs"),
        Map.entry("Bhutan", "bt"),
        Map.entry("Bouvet Island", "bv"),
        Map.entry("Botswana", "bw"),
        Map.entry("Belarus", "by"),
        Map.entry("Belize", "bz"),
        Map.entry("Canada", "ca"),
        Map.entry("Cocos (Keeling) Islands", "cc"),
        Map.entry("Congo (DRC)", "cd"),
        Map.entry("Central African Republic", "cf"),
        Map.entry("Congo (Republic)", "cg"),
        Map.entry("Switzerland", "ch"),
        Map.entry("Côte d'Ivoire", "ci"),
        Map.entry("Cook Islands", "ck"),
        Map.entry("Chile", "cl"),
        Map.entry("Cameroon", "cm"),
        Map.entry("China", "cn"),
        Map.entry("Colombia", "co"),
        Map.entry("Costa Rica", "cr"),
        Map.entry("Cuba", "cu"),
        Map.entry("Cabo Verde", "cv"),
        Map.entry("Curaçao", "cw"),
        Map.entry("Cyprus", "cy"),
        Map.entry("Czechia", "cz"),
        Map.entry("Germany", "de"),
        Map.entry("Djibouti", "dj"),
        Map.entry("Denmark", "dk"),
        Map.entry("Dominica", "dm"),
        Map.entry("Dominican Republic", "do"),
        Map.entry("Algeria", "dz"),
        Map.entry("Ecuador", "ec"),
        Map.entry("Estonia", "ee"),
        Map.entry("Egypt", "eg"),
        Map.entry("Western Sahara", "eh"),
        Map.entry("Eritrea", "er"),
        Map.entry("Spain", "es"),
        Map.entry("Ethiopia", "et"),
        Map.entry("Finland", "fi"),
        Map.entry("Fiji", "fj"),
        Map.entry("Falkland Islands", "fk"),
        Map.entry("Micronesia", "fm"),
        Map.entry("Faroe Islands", "fo"),
        Map.entry("France", "fr"),
        Map.entry("Gabon", "ga"),
        Map.entry("United Kingdom", "gb"),
        Map.entry("England", "gb-eng"),
        Map.entry("Northern Ireland", "gb-nir"),
        Map.entry("Scotland", "gb-sct"),
        Map.entry("Wales", "gb-wls"),
        Map.entry("Grenada", "gd"),
        Map.entry("Georgia", "ge"),
        Map.entry("French Guiana", "gf"),
        Map.entry("Guernsey", "gg")
 );

    private String selectedCountry;

    public Geography() {
        List<String> countries = new ArrayList<>(countryCodeMap.keySet());
        selectedCountry = countries.get((int)(Math.random() * countries.size()));
        countryCode = countryCodeMap.get(selectedCountry).toUpperCase(); 
        title = selectedCountry;   
        
        try
        (
        // create a database connection
            Connection conn = DriverManager.getConnection("jdbc:geographydata.db");
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM countries WHERE id = ? AND population IS NOT NULL AND language IS NOT NULL")
        )
        {      
            stmt.setString(1, countryCode); 
            stmt.setQueryTimeout(30);  // set timeout to 30 sec.

            ResultSet rs = stmt.executeQuery();
            if(rs.next()){
                rs = stmt.executeQuery();
                genresArr.add(rs.getString("language"));
                creators.add(selectedCountry);
                releaseDate = rs.getInt("population");
            }
        }
        catch(SQLException e)
        {
        // if the error message is "out of memory",
        // it probably means no database file is found
        e.printStackTrace(System.err);
        }       
    }

    public String getSelectedCountry() {
        return selectedCountry;
    }

    public  String getFlagImagePath() {
        String code = countryCodeMap.get(selectedCountry);
        return "/flags/" + code + ".png"; // resource path
    }

    @Override
    public ArrayList<String> getThreeRandomNames() {
        ArrayList<String> all = new ArrayList<>(countryCodeMap.keySet());
        all.remove(selectedCountry);
        Collections.shuffle(all);
        return new ArrayList<>(all.subList(0, 3));
    }
}
